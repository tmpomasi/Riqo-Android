# RIQO — Guía completa para publicar en Play Store

## ¿Qué contiene este paquete?

```
riqo-pwa/
├── index.html          ← Tu app completa (PWA)
├── manifest.json       ← Configuración PWA
├── sw.js               ← Service Worker (funciona offline)
├── icons/              ← Todos los íconos (12 tamaños)
├── screenshots/        ← Capturas para Play Store
└── android-twa/        ← Proyecto Android Studio (TWA)
    ├── app/
    │   ├── build.gradle
    │   └── src/main/
    │       ├── AndroidManifest.xml
    │       └── res/...
    ├── build.gradle
    ├── settings.gradle
    └── .well-known/
        └── assetlinks.json
```

---

## PASO 1 — Alojar tu PWA en internet

La app necesita estar en una URL HTTPS para funcionar en la Play Store.

### Opción A: GitHub Pages (GRATIS, recomendado)
1. Crea cuenta en github.com
2. Nuevo repositorio → `riqo-app` (público)
3. Sube los archivos: `index.html`, `manifest.json`, `sw.js`, carpeta `icons/`
4. Settings → Pages → Source: main branch
5. Tu URL será: `https://TU_USUARIO.github.io/riqo-app`

### Opción B: Netlify (GRATIS)
1. Entra a netlify.com
2. "Deploy manually" → arrastra la carpeta `riqo-pwa/`
3. Obtienes URL automática tipo `https://riqo-xxxxx.netlify.app`

### Opción C: Dominio propio
1. Compra dominio (ej. `riqo.app`, `riqofinanzas.com`)
2. Sube los archivos al hosting
3. Activa SSL/HTTPS (obligatorio)

---

## PASO 2 — Configurar la URL en el proyecto Android

Edita estos 2 archivos con tu URL real:

**`android-twa/app/src/main/res/values/strings.xml`**
```xml
<string name="app_url">https://TU_URL_REAL.com</string>
```

**`android-twa/app/src/main/AndroidManifest.xml`**
```xml
<data android:scheme="https" android:host="TU_URL_REAL.com" />
```

---

## PASO 3 — Instalar Android Studio

1. Descarga desde: https://developer.android.com/studio
2. Instala con configuración por defecto
3. Abre el proyecto: File → Open → selecciona carpeta `android-twa/`
4. Espera que Gradle sincronice (3-5 minutos)

---

## PASO 4 — Generar el APK/AAB firmado

### 4.1 Crear tu keystore (solo una vez)
```
Build → Generate Signed Bundle/APK → Android App Bundle → Create new...
```
- **Key store path**: guarda en lugar seguro (ej. Desktop/riqo-keystore.jks)
- **Password**: mínimo 6 caracteres, GUÁRDALO BIEN
- **Alias**: riqo
- **Validity**: 25 años
- **Name**: Tu nombre o empresa

⚠️ **IMPORTANTE**: Sin el keystore no puedes actualizar la app. Guarda una copia en la nube.

### 4.2 Generar AAB (Android App Bundle)
```
Build → Generate Signed Bundle/APK
→ Android App Bundle → Next
→ Selecciona tu keystore → Next
→ Release → Finish
```
El archivo `.aab` se genera en: `app/release/app-release.aab`

---

## PASO 5 — Digital Asset Links (vincula app con web)

Este paso verifica que tu app Android es legítima y puede usar la URL.

### 5.1 Obtener tu SHA-256 fingerprint
En Android Studio, Terminal:
```bash
keytool -list -v -keystore TU_KEYSTORE.jks -alias riqo
```
Copia el SHA-256 que aparece.

### 5.2 Actualizar assetlinks.json
Edita `.well-known/assetlinks.json`:
```json
"sha256_cert_fingerprints": ["TU:SHA:256:AQUI:XX:XX:XX"]
```

### 5.3 Subir a tu web
Sube el archivo a:
```
https://tudominio.com/.well-known/assetlinks.json
```
Debe ser accesible públicamente.

### 5.4 Verificar
```
https://digitalassetlinks.googleapis.com/v1/statements:list?
  source.web.site=https://tudominio.com&
  relation=delegate_permission/common.handle_all_urls
```

---

## PASO 6 — Crear cuenta Google Play Developer

1. Ve a: https://play.google.com/console
2. Paga el registro único: **$25 USD**
3. Completa tu perfil de desarrollador
4. Acepta políticas del programa

---

## PASO 7 — Publicar en Play Store

### 7.1 Crear nueva app
- Play Console → "Crear app"
- Nombre: **RIQO**
- Idioma: Español
- Tipo: App
- Gratis/Pagada: Gratis

### 7.2 Ficha de la tienda (lo que ve el usuario)
- **Título**: RIQO — Libertad Financiera
- **Descripción corta** (80 chars):
  > Tu app de finanzas personales. Mide tu Índice de Riqueza.

- **Descripción completa** (4000 chars):
  > RIQO es la app de finanzas personales diseñada para Latinoamérica que te ayuda a alcanzar tu libertad financiera.
  >
  > 🧭 ÍNDICE DE RIQUEZA ÚNICO
  > Una fórmula exclusiva que mide en meses cuánto tiempo podrías vivir sin trabajar. No solo saldos — riqueza real.
  >
  > ✅ FUNCIONES PRINCIPALES:
  > • Registro de ingresos, gastos, inversiones y préstamos
  > • Índice de Riqueza en tiempo real
  > • Proyección de libertad financiera con inteligencia
  > • Sistema de estrellas y logros motivacionales
  > • Reportes y análisis detallados
  > • Multi-cuenta y multi-divisa (PEN, USD, MXN, COP, ARS, CLP)
  > • 100% privado — datos en tu dispositivo
  > • Sin publicidad, sin suscripciones
  >
  > 🔒 PRIVACIDAD TOTAL
  > Todos tus datos se guardan solo en tu celular. Nunca salen a servidores.

- **Icono**: sube `icons/icon-512.png`
- **Gráfico destacado**: imagen de 1024×500px (puedes crear en Canva)
- **Capturas de pantalla**: mínimo 2 (usa las de `screenshots/`)

### 7.3 Categoría y clasificación
- Categoría: **Finanzas**
- Subcategoría: Gestión del dinero personal
- Clasificación de contenido: Todos (sin contenido sensible)
- Responde el cuestionario de clasificación de contenido

### 7.4 Subir el AAB
- Producción → Versiones → Crear versión
- Sube `app-release.aab`
- Notas de la versión: "Versión inicial de RIQO"

### 7.5 Política de privacidad (OBLIGATORIO)
Necesitas URL con política. Puedes crear gratis en:
- https://privacypolicygenerator.info
- O pega este texto básico en una página web:

> **Política de Privacidad de RIQO**
> RIQO no recopila, almacena ni transmite ningún dato personal a servidores externos.
> Todos los datos financieros se almacenan exclusivamente en el dispositivo del usuario.
> No utilizamos cookies de seguimiento ni publicidad.

---

## PASO 8 — Proceso de revisión

- Google revisa la app en 1-7 días hábiles
- Te notifican por email
- Si hay problemas, te indican qué corregir
- Una vez aprobada, aparece en Play Store en ~24h

---

## REQUISITOS MÍNIMOS PARA APROBAR

✅ HTTPS en tu URL  
✅ manifest.json válido con display:standalone  
✅ Service Worker funcionando  
✅ assetlinks.json accesible  
✅ Ícono 512×512px  
✅ 2+ capturas de pantalla  
✅ Política de privacidad  
✅ Descripción completa  
✅ Clasificación de contenido completada  

---

## HERRAMIENTAS ÚTILES

- **PWABuilder** (Microsoft): https://www.pwabuilder.com — genera el APK automáticamente desde tu URL
- **Lighthouse** (Chrome DevTools): verifica que tu PWA es válida
- **Digital Asset Links Tester**: https://developers.google.com/digital-asset-links/tools/generator

---

## ALTERNATIVA MÁS RÁPIDA: PWABuilder

Si no quieres usar Android Studio:

1. Ve a https://www.pwabuilder.com
2. Ingresa tu URL (ej. `https://usuario.github.io/riqo-app`)
3. Clic en "Package for stores"
4. Selecciona "Google Play"
5. Descarga el paquete Android listo para subir

PWABuilder genera el TWA automáticamente con tu app. Solo necesitas firmarlo con tu keystore.

---

## SOPORTE

Para cualquier duda sobre el proceso de publicación:
- Documentación TWA: https://developer.chrome.com/docs/android/trusted-web-activity
- Play Console Help: https://support.google.com/googleplay/android-developer
